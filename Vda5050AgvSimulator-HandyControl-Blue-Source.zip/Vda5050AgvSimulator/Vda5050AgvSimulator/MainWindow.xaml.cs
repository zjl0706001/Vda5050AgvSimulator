﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using Vda5050AgvSimulator.Services.Agv;
using Vda5050AgvSimulator.Models.Agv;
using Vda5050AgvSimulator.ViewModels;
using Vda5050AgvSimulator.Views;
using HandyControl.Data;
using NotifyIcon = HandyControl.Controls.NotifyIcon;

namespace Vda5050AgvSimulator;

public partial class MainWindow
{
    private readonly NotifyIcon _notifyIcon = new();

    private bool _isRealExit;
    private bool _sidebarCollapsed;

    private readonly AgvListView _fleet;
    private readonly MqttConfigView _mqtt;
    private AgvOperationView? _operations;
    private OrderView? _orders;
    private PlcConfigWindow? _plc;

    public MainWindow()
    {
        InitializeComponent();

        ConfigStoreService.Instance.EnsureLoaded();

        MapStoreService.Initialize();

        ConfigStoreService.Instance.StartMapConfigWatcher();

        DataContext = new MainViewModel();

        _mqtt = new MqttConfigView();
        ConnectionFooter.DataContext = _mqtt;
        _fleet = new AgvListView();
        var store = AgvStoreService.Instance;
        VehicleSelection.ItemsSource = store.Agvs;
        VehicleSelection.SelectedItem = store.SelectedAgv;
        store.SelectedAgvChanged += CurrentVehicle_Changed;

        NavigationMenu.PageSelected += Navigate;
        Navigate("fleet");
        InitTrayIcon();

        Closing += MainWindow_Closing;

        Closed += MainWindow_Closed;
    }

    private void Navigate(string page)
    {
        PageContent.Content = page switch
        {
            "fleet" => _fleet,
            "operations" => _operations ??= new AgvOperationView(),
            "orders" => _orders ??= new OrderView(),
            "mqtt" => _mqtt,
            "plc" => _plc ??= new PlcConfigWindow(),
            _ => throw new ArgumentOutOfRangeException(nameof(page))
        };
        PageTitle.Text = NavigationMenu.SelectedPageTitle;
        VehiclePicker.Visibility = page is "operations" or "orders" ? Visibility.Visible : Visibility.Collapsed;
    }

    private void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (e.WidthChanged) UpdateSidebar(e.NewSize.Width);
    }

    private void ToggleSidebar(object sender, RoutedEventArgs e)
    {
        _sidebarCollapsed = !_sidebarCollapsed;
        UpdateSidebar(ActualWidth);
    }

    private void UpdateSidebar(double width)
    {
        var narrow = width < 900;
        var compact = narrow || _sidebarCollapsed;
        NavigationMenu.Compact = compact;
        SidebarColumn.Width = new GridLength(compact ? 68 : 212);
        ProductLabel.Visibility = compact ? Visibility.Collapsed : Visibility.Visible;
        ConnectionFooter.Visibility = ProductLabel.Visibility;
        SidebarToggle.Visibility = narrow ? Visibility.Collapsed : Visibility.Visible;
        HeaderDivider.Visibility = SidebarToggle.Visibility;
        var label = compact ? "展开菜单" : "收起菜单";
        SidebarToggle.ToolTip = label;
        System.Windows.Automation.AutomationProperties.SetName(SidebarToggle, label);
        PageContent.Margin = new Thickness(narrow ? 8 : 16);
    }

    private void OpenMqttPage(object sender, RoutedEventArgs e) => NavigationMenu.SelectPage("mqtt");

    private void CurrentVehicle_Changed(object sender, AgvModel vehicle)
    {
        VehicleSelection.SelectedItem = AgvStoreService.Instance.SelectedAgv;
    }

    private void VehicleSelection_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (VehicleSelection.SelectedItem is AgvModel vehicle && vehicle != AgvStoreService.Instance.SelectedAgv)
        {
            AgvStoreService.Instance.SetSelectedAgv(vehicle);
        }
    }

    /// <summary>
    /// 初始化托盘图标。
    /// </summary>
    private void InitTrayIcon()
    {
        var show = new MenuItem { Header = "显示主窗口" };
        show.Click += (_, _) => ShowMainWindow();

        var hide = new MenuItem { Header = "隐藏到托盘" };
        hide.Click += (_, _) => HideMainWindowToTray();

        var exit = new MenuItem { Header = "退出程序" };
        exit.Click += (_, _) => ExitApplication();

        var menu = new ContextMenu();
        menu.Items.Add(show);
        menu.Items.Add(hide);
        menu.Items.Add(new Separator());
        menu.Items.Add(exit);

        _notifyIcon.Text = "VDA5050 AGV Simulator";
        _notifyIcon.ContextMenu = menu;
        _notifyIcon.MouseDoubleClick += (_, _) => ShowMainWindow();

        // 托盘控件独立于主窗口的可视树，窗口隐藏后仍需接收消息。
        _notifyIcon.Init();
    }

    /// <summary>
    /// 隐藏主窗口到托盘。
    /// </summary>
    private void HideMainWindowToTray()
    {
        if (!IsVisible)
        {
            return;
        }

        Hide();

        ShowInTaskbar = false;

        _notifyIcon.ShowBalloonTip("VDA5050 AGV Simulator", "程序已隐藏到托盘区，双击图标可恢复。", NotifyIconInfoType.Info);
    }

    /// <summary>
    /// 显示主窗口。
    /// </summary>
    private void ShowMainWindow()
    {
        if (!ShowInTaskbar)
        {
            ShowInTaskbar = true;
        }

        if (!IsVisible)
        {
            Show();
        }

        if (WindowState == WindowState.Minimized)
        {
            WindowState = WindowState.Normal;
        }

        Activate();

        Focus();
    }

    /// <summary>
    /// 点击关闭按钮时默认隐藏到托盘，不直接退出。
    /// </summary>
    private void MainWindow_Closing(object sender, CancelEventArgs e)
    {
        if (_isRealExit)
        {
            return;
        }

        e.Cancel = true;

        Dispatcher.BeginInvoke(new Action(HideMainWindowToTray));
    }

    /// <summary>
    /// 从托盘菜单真正退出程序。
    /// </summary>
    private void ExitApplication()
    {
        _isRealExit = true;

        Application.Current.Shutdown();
    }

    /// <summary>
    /// 窗口关闭后释放托盘图标资源。
    /// </summary>
    private void MainWindow_Closed(object sender, EventArgs e)
    {
        AgvStoreService.Instance.SelectedAgvChanged -= CurrentVehicle_Changed;
        _plc?.CloseTools();
        _notifyIcon.Dispose();
    }
}