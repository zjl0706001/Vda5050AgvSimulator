using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HandyControl.Controls;
using HandyControl.Data;

namespace Vda5050AgvSimulator.Views;

public partial class WorkspaceMenu : UserControl
{
    public static readonly DependencyProperty CompactProperty = DependencyProperty.Register(
        nameof(Compact), typeof(bool), typeof(WorkspaceMenu), new PropertyMetadata(false));

    public bool Compact
    {
        get => (bool)GetValue(CompactProperty);
        set => SetValue(CompactProperty, value);
    }

    private SideMenuItem _selected;
    public string SelectedPageTitle => (string)_selected.Header;

    public event Action<string>? PageSelected;

    public WorkspaceMenu()
    {
        InitializeComponent();
        _selected = Fleet;
    }

    public void SelectPage(string key)
    {
        var item = Menu.Items.OfType<SideMenuItem>().FirstOrDefault(candidate => Equals(candidate.Tag, key));
        if (item != null)
            item.RaiseEvent(new RoutedEventArgs(SideMenuItem.SelectedEvent, item));
    }

    private void Menu_SelectionChanged(object sender, FunctionEventArgs<object> e)
    {
        if (e.Info is SideMenuItem item && item != _selected)
        {
            _selected = item;
            PageSelected?.Invoke((string)item.Tag);
        }
    }

    private void Menu_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.FocusedElement is not SideMenuItem item) return;
        int index = Menu.Items.IndexOf(item);
        switch (e.Key)
        {
            case Key.Up:
                ((SideMenuItem)Menu.Items[Math.Max(0, index - 1)]).Focus();
                break;
            case Key.Down:
                ((SideMenuItem)Menu.Items[Math.Min(Menu.Items.Count - 1, index + 1)]).Focus();
                break;
            case Key.Enter:
            case Key.Space:
                SelectPage((string)item.Tag);
                break;
            default:
                return;
        }
        e.Handled = true;
    }
}
